package gps.acquisition;


public class Acquisition {
	
	public Acquisition(int nrOfSamples){
		
	}
	
	public void enterSample(float real, float imag){
	}
	
	public void enterCode(float real, float imag){
	}
	
	public boolean startAcquisition(){
		
		return false;
	}
	
	public int getDopplerverschiebung(){
		return 0;
	}
	
	public int getCodeVerschiebung(){
		return 0;
	}
	
	

}
