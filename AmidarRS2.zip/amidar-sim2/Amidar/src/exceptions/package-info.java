/**
 *  This Package contains all AMIDAR-Simulator related Exceptions
 */
/**
 * @author jung
 *
 */
package exceptions;