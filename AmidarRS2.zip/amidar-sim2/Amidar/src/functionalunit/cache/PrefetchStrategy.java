package functionalunit.cache;

public enum PrefetchStrategy {
	NONE,
	LINEAR,
	UNROLL
}
