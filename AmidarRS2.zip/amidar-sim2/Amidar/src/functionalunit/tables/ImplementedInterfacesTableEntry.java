package functionalunit.tables;

public class ImplementedInterfacesTableEntry extends TableEntry {

	public ImplementedInterfacesTableEntry(int[] data) {
		super(data);
	}

}
