package functionalunit.tables;

public class ConstantPoolEntry extends TableEntry {

	public ConstantPoolEntry(int[] data) {
		super(data);
	}
	


}
