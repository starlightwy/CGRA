package functionalunit.tables;

public class InterfaceTableEntry extends TableEntry {

	public InterfaceTableEntry(int[] data) {
		super(data);
	}
	


}
