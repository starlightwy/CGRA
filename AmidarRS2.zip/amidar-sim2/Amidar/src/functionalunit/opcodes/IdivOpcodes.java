package functionalunit.opcodes;

public enum IdivOpcodes implements FUOpcodes {
	IREM,
	LDIV,
	IDIV,
	LREM;
}
