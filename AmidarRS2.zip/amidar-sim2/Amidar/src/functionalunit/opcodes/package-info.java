/**
 * 
 */
/**
 * @author jung
 *
 */
package functionalunit.opcodes;