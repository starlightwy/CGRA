package functionalunit.opcodes;

public enum AcceleratorCoreOpcodes implements FUOpcodes {
	INVOKE;
}
