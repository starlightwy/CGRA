package functionalunit.opcodes;

public enum CgraOpcodes implements FUOpcodes {
	INIT,
	LOADPROGRAM,
	SENDLOCALVAR,
	RUN,
	RECEIVELOCALVAR;
}
