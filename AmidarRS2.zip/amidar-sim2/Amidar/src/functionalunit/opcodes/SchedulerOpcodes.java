package functionalunit.opcodes;

public enum SchedulerOpcodes implements FUOpcodes {
	DISABLESCHEDULING,
	ENABLESCHEDULING,
	FORCESCHEDULING;
}
