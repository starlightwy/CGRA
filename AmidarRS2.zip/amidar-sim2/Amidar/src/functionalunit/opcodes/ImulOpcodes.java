package functionalunit.opcodes;

public enum ImulOpcodes implements FUOpcodes {
	IMUL,
	LMUL;
}
