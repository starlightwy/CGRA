package functionalunit.opcodes;


public interface FUOpcodes {
//	public int getNumberOfOperands();
}
