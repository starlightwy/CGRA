package functionalunit.opcodes;

public enum FdivOpcodes implements FUOpcodes {
	DDIV,
	FDIV;
}
