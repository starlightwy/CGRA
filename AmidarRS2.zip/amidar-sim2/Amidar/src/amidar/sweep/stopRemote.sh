cd ../../..
java -cp ../Amidar/bin:../AmidarTools/bin:../AmidarTools/lib/axtConverter.jar:../AmidarTools/lib/bcel-5.2.jar:../AmidarTools/lib/commons-lang-2.6.jar:../AmidarTools/lib/j-text-utils-0.3.3.jar:../AmidarTools/lib/json-simple-1.1.1.jar:../AmidarTools/lib/lombok.jar:../AXTLoader/bin:../Synthesis/bin amidar.sweep.AmidarRemoteManager close $1 $2
