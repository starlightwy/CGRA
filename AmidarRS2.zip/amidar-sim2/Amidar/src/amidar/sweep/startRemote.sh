ssh $1@$2 'bash -s' < remote.sh
