package de.amidar;


public class FIFO_UART implements AmidarPeripheral {
	public byte data;
	
	private FIFO_UART () {}
}
