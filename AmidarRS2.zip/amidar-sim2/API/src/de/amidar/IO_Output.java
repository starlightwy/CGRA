package de.amidar;

public class IO_Output implements AmidarPeripheral {
	public int data;
	
	private IO_Output () {}
}
