package de.amidar;

public class IO_Input implements AmidarPeripheral {
	public int data;
	
	private IO_Input () {}
}
