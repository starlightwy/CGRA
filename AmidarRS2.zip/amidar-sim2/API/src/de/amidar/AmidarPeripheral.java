package de.amidar;

public interface AmidarPeripheral {
}
