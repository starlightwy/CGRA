package java.io;

public class RandomAccessFile {
	
}
