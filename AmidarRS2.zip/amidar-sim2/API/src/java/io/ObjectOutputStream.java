package java.io;

public class ObjectOutputStream {

	public void defaultWriteObject () {
		// TODO Auto-generated method stub
	}

	public void writeInt (int len) {
		// TODO Auto-generated method stub
	}

	public void writeObject (Object object) {
		// TODO Auto-generated method stub
	}

	public void writeFloat (float loadFactor) {
		// TODO Auto-generated method stub
		
	}

	public void write (byte[] byteArray, int i, int length) {
		// TODO Auto-generated method stub
		
	}
	
	// TODO: ObjectOutputStream
}
