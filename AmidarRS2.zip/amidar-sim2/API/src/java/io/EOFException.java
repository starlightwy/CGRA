package java.io;

public class EOFException extends IOException {

}
