package java.io;

public class FileNotFoundException {}
