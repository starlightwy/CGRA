package java.io;

public class ObjectInputStream {

	public void defaultReadObject () {
		// TODO Auto-generated method stub
	}

	public int readInt () {
		// TODO Auto-generated method stub
		return 0;
	}

	public Object readObject () {
		// TODO Auto-generated method stub
		return null;
	}

	public float readFloat () {
		// TODO Auto-generated method stub
		return 0;
	}

	public void read (byte[] byteArray, int i, int length) {
		// TODO Auto-generated method stub
		
	}

	// TODO: ObjectInputStream
}
