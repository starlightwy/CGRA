package java.io;

public class IOException extends Exception {
	private static final long serialVersionUID = 7818375828146090155L;

	public IOException () {
	}

	public IOException (String message) {
		super (message);
	}
}
