package java.io;

public class UnsupportedEncodingException extends IOException {
	private static final long serialVersionUID = -4274276298326136670L;

	public UnsupportedEncodingException () {
	}

	public UnsupportedEncodingException (String message) {
		super (message);
	}
}
