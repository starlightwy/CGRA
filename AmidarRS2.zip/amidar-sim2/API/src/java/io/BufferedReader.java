package java.io;

public class BufferedReader {

}
