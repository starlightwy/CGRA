package java.io;

public class InputStreamReader {

}
