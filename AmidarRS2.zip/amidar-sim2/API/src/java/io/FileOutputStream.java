package java.io;

public class FileOutputStream  extends OutputStream {

	public void write(int b) throws IOException {
		
	}
	
}
