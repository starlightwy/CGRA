package java.util;

import java.io.Serializable;

public final class Locale implements Serializable, Cloneable {
	private static final long serialVersionUID = 1L;

	public static Locale getDefault () {
		// TODO Auto-generated method stub
		return null;
	}
	
	// TODO: Placeholder
}
