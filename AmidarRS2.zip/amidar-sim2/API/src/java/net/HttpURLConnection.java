package java.net;

public class HttpURLConnection {}
