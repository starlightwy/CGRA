package java.net;

public class URL {}
