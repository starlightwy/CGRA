package java.net;

public class URLConnection {}
