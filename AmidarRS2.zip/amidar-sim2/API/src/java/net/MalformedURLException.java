package java.net;

public class MalformedURLException {}
