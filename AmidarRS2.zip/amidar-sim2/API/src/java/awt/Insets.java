package java.awt;

public class Insets {}
