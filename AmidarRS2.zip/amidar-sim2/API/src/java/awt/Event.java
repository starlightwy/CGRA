package java.awt;

public class Event {}
