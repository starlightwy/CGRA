package java.awt;

public class Window {}
