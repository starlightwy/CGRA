package java.awt;

public class TextArea {}
