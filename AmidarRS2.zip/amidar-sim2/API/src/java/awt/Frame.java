package java.awt;

public class Frame {}
