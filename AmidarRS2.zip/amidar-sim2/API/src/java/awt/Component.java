package java.awt;

public class Component {}
