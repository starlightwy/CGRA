package java.applet;

public class Applet {}
