package java.lang;

public class ArithmeticException {}
