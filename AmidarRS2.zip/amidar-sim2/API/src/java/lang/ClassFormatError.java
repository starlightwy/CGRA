package java.lang;

public class ClassFormatError extends LinkageError {
	
}
