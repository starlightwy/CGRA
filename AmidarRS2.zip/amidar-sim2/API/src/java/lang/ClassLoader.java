package java.lang;

public abstract class ClassLoader {
	// Placeholder for classes that have a reference to this class
}
