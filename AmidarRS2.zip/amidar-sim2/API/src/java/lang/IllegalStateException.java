package java.lang;

public class IllegalStateException extends RuntimeException {
	private static final long serialVersionUID = -1848914673093119416L;

	public IllegalStateException () {
	}

	public IllegalStateException (String s) {
		super (s);
	}

}
