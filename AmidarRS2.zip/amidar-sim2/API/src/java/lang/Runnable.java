package java.lang;

public interface Runnable {
   public abstract void run();
}
