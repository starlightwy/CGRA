package java.lang;

public class InstantiationException {}
