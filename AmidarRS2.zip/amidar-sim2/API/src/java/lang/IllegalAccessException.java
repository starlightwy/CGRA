package java.lang;

public class IllegalAccessException {}
