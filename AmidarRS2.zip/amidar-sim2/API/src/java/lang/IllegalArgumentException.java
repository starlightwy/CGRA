package java.lang;

public class IllegalArgumentException extends RuntimeException {
	private static final long serialVersionUID = -5365630128856068164L;

	public IllegalArgumentException () {
	}

	public IllegalArgumentException (String s) {
		super (s);
	}

}
