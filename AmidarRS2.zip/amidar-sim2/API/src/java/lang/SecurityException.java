package java.lang;

public class SecurityException {}
