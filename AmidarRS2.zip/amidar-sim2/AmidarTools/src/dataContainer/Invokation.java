package dataContainer;

public class Invokation {
	
	public int address, cti, amti;
	
	public Invokation(int address, int cti, int amti){
		this.address = address;
		this.cti = cti;
		this.amti = amti;
	}

}
